/*
  ==============================================================================

	This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A2StarterAudioProcessorEditor::A2StarterAudioProcessorEditor(A2StarterAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
	// Make sure that before the constructor has finished, you've set the
	// editor's size to whatever you need it to be.
	setSize(500, 350);

	//Dry volume slider
	drySlider.setSliderStyle(juce::Slider::Rotary);
	drySlider.setRange(0, 1.0, 0.01);
	drySlider.setValue(0);
	drySlider.setTextValueSuffix("%");
	
	addAndMakeVisible(&drySlider);
	drySlider.addListener(this);
	//dry volume label
	dryLabel.setText("Dry Volume:", juce::dontSendNotification);
	//dryLabel.attachToComponent(&drySlider, true);
	dryLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	dryLabel.setJustificationType(juce::Justification::bottom);
	addAndMakeVisible(&dryLabel);

	//Wet Volume slider
	wetSlider.setSliderStyle(juce::Slider::Rotary);
	wetSlider.setRange(0, 1.0, 0.01);
	wetSlider.setValue(0);
	wetSlider.setTextValueSuffix("%");
	addAndMakeVisible(&wetSlider);
	wetSlider.addListener(this);
	//wet volume label
	wetLabel.setText("Wet Volume:", juce::dontSendNotification);
	//wetLabel.attachToComponent(&wetSlider, true);
	wetLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	wetLabel.setJustificationType(juce::Justification::bottom);
	addAndMakeVisible(&wetLabel);

	//delay slider
	delaySlider.setSliderStyle(juce::Slider::LinearBar);
	delaySlider.setRange(0.0001, 3.0, 0.1);
	delaySlider.setValue(0.0);
	delaySlider.setTextValueSuffix(" s");
	addAndMakeVisible(&delaySlider);
	delaySlider.addListener(this);
	//Delay label
	delayLabel.setText("Delay Time:", juce::dontSendNotification);
	delayLabel.attachToComponent(&delaySlider, true);
	delayLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	delayLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(&delayLabel);

	//Feedback slider
	feedbackSlider.setSliderStyle(juce::Slider::LinearBar);
	feedbackSlider.setRange(0, 1.0, 0.01);
	feedbackSlider.setValue(0);
	feedbackSlider.setTextValueSuffix(" %");
	addAndMakeVisible(&feedbackSlider);
	feedbackSlider.addListener(this);
	//Feedback label	
	feedbackLabel.setText("Feedback:", juce::dontSendNotification);
	feedbackLabel.attachToComponent(&feedbackSlider, true);
	feedbackLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	feedbackLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(&feedbackLabel);

	//Ping Pong On/Off ComboBox
	addAndMakeVisible(pingpong);
	pingpong.addItem("Off", 1);
	pingpong.addItem("On", 2);
	pingpong.setSelectedId(1);
	//Ping pong label
	pingPongLabel.setText("PingPong:", juce::dontSendNotification);
	pingPongLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	pingPongLabel.attachToComponent(&pingpong, true);
	pingPongLabel.setJustificationType(juce::Justification::centred);
	addAndMakeVisible(&pingPongLabel);

	getLookAndFeel().setColour(juce::Slider::thumbColourId, juce::Colours::orange);
}

A2StarterAudioProcessorEditor::~A2StarterAudioProcessorEditor()
{
}

//==============================================================================
void A2StarterAudioProcessorEditor::paint(juce::Graphics& g)
{
	// fill the whole window white
	g.fillAll(juce::Colours::darkgrey);

	// set the current drawing colour to black
	g.setColour(juce::Colours::orange);

	// set the font size and draw text to the screen
	g.setFont(20.0f);

	g.drawFittedText("A2 Delay", 0, 15, getWidth(), 30, juce::Justification::centred, 1);
}

void A2StarterAudioProcessorEditor::resized()
{
	// This is generally where you'll want to lay out the positions of any
	// subcomponents in your editor..
	// sets the position and size of the slider with arguments (x, y, width, height)
	drySlider.setBounds(40, 70, getWidth() - 299, 100);
	wetSlider.setBounds(250, 70, getWidth() - 299, 100);
	delaySlider.setBounds(100, 180, getWidth() - 130, 25);
	feedbackSlider.setBounds(100, 230, getWidth() - 130, 25);
	dryLabel.setBounds(35, -10, getWidth() - 130, 100);
	wetLabel.setBounds(245, -10, getWidth() - 130, 100);
	pingPongLabel.setBounds(70, 280, getWidth() - 130, 25);
	pingpong.setBounds(100, 280, getWidth() - 350, 25);
}

void A2StarterAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
	audioProcessor.volumeBoost = (float)drySlider.getValue();
	audioProcessor.delayBoost = (float)delaySlider.getValue();
	audioProcessor.wetBoost = (float)wetSlider.getValue();
	audioProcessor.feedbackBoost = (float)feedbackSlider.getValue();
	
}

void A2StarterAudioProcessorEditor::comboBoxChanged(juce::ComboBox* combobox) {
	audioProcessor.pPong = pingpong.getSelectedId();
}


